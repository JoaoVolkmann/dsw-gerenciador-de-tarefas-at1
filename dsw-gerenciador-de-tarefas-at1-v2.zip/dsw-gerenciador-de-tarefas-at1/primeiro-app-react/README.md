# Meu primeiro app React

Primeiro contato com React + Vite na disciplina de DSW.

O app mostra a meta de tarefas do dia: cada clique em "Concluí uma tarefa" soma 1 até chegar em 5, "Zerar" volta para 0 e "Modo foco" troca as cores da tela.

## O que ele usa

- `useState` para guardar o número de tarefas concluídas e se o modo foco está ligado
- Componente `BotaoAcao`, reaproveitado nos três botões e configurado por props (`texto`, `aoClicar`, `tipo`, `desabilitado`)
- Renderização condicional: a mensagem "Meta batida!" só aparece quando chega em 5

## Como rodar

```bash
cd primeiro-app-react
npm install
npm run dev
```

Abra o endereço que aparecer no terminal (normalmente `http://localhost:5173`).
