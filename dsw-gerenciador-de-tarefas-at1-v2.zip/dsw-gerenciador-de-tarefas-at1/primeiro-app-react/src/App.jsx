import { useState } from 'react'
import BotaoAcao from './BotaoAcao.jsx'

const META_DIARIA = 5

function App() {
  // Estado: quando muda, o React desenha a tela de novo sozinho
  const [concluidas, setConcluidas] = useState(0)
  const [modoFoco, setModoFoco] = useState(false)

  const metaBatida = concluidas >= META_DIARIA
  const porcentagem = Math.round((concluidas / META_DIARIA) * 100)

  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '16px',
        padding: '24px',
        textAlign: 'center',
        backgroundColor: modoFoco ? '#0f172a' : '#f8fafc',
        color: modoFoco ? '#f8fafc' : '#0f172a',
      }}
    >
      <h1 style={{ margin: 0 }}>Meta do dia</h1>

      <p style={{ fontSize: '20px', margin: 0 }}>
        {concluidas} de {META_DIARIA} tarefas concluídas ({porcentagem}%)
      </p>

      {metaBatida && <p style={{ margin: 0, fontWeight: 700 }}>Meta batida! 🎉</p>}

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', justifyContent: 'center' }}>
        <BotaoAcao
          texto="Concluí uma tarefa"
          aoClicar={() => setConcluidas(concluidas + 1)}
          desabilitado={metaBatida}
        />
        <BotaoAcao texto="Zerar" tipo="neutro" aoClicar={() => setConcluidas(0)} />
        <BotaoAcao
          texto={modoFoco ? 'Sair do modo foco' : 'Modo foco'}
          tipo="neutro"
          aoClicar={() => setModoFoco(!modoFoco)}
        />
      </div>
    </main>
  )
}

export default App
